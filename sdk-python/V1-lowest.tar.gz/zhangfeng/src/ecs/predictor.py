#coding=utf-8
import datetime

Debug = False

def predict_vm(ecs_lines, input_lines):
    # Do your work from here#
    result = []
    if ecs_lines is None:
        print 'ecs information is none'
        return result
    if input_lines is None:
        print 'input file information is none'
        return result

#读取训练数据
    for item in ecs_lines:
        values = item.split("\t")
        #print values
        uuid = values[0]
        flavorName = values[1]
        createTime = values[2]
        #print uuid,flavorName,createTime



#读取输入数据
    cpu = 0
    mem = 0
    ram = 0
    OptimizaType = ''
    VirtualComputer = []
    BeginTime = datetime.datetime.strptime(input_lines[-2].split(' ')[0], '%Y-%m-%d')
    EndTime = datetime.datetime.strptime(input_lines[-1].split(' ')[0], '%Y-%m-%d')
    Time = (EndTime-BeginTime).days
    print Time


    for index, item in enumerate(input_lines):
        if index == 0:
            values = item.split(" ")
            cpu = values[0]
            mem = values[1]
            ram = values[2]
        elif index == 2:
            for i in range(index+1, index+int(item[0])+1):
                flag = input_lines[i].split(' ')
                VirtualComputer.append([flag[0],flag[1],flag[2].replace('\n','')])

        if item.split('\n')[0] == "CPU" or item.split('\n')[0] == "MEM":
            OptimizaType = item.split('\n')[0]


    if Debug:
        print '预测时间间隔' , Time
        print '虚拟主机类型' , VirtualComputer
        print '优化类型' , OptimizaType

    result.append(str(len(VirtualComputer)))
    temp = '\n'
    temp += str(len(VirtualComputer))+'\n'
    num = 1
    for i,j,k in VirtualComputer:
        result.append(i + '\t' + '1')
        if num != len(VirtualComputer):
            temp += str(num) + '\t' + i + '\t' + '1' + '\n'
        else:
            temp += str(num) + '\t' + i + '\t' + '1'
        num += 1
    result.append(temp)
    #print temp

    return result
